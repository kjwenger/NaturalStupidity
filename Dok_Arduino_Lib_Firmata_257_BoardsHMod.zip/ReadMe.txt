Diese Version der (Standard)Firmata (V2.5.7 mit ergänzter Boards.h) 
funktioniert mit Arduino Uno R3, Arduino Uno R4 Minima und Arduino Uno R4 WiFi mit vvvv beta und gamma als Host.
Kopieren sie den Ordner Firmata in die Sketchbook Location ihrer Arduino Uno IDE (i.d.R. ~\Dokumente\Arduino) in das Verzeichnis libraries.
Sollte das Verzeichnis libraries nicht existieren, legen sie dieses bitte an.
Anschließend könnnen sie in der Arduino-IDE das Beispiel Firmata / StandardFirmata öffnen.